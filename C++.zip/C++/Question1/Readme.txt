g++ main.cpp Bike.cpp Car.cpp Truck.cpp -o insurance_program
