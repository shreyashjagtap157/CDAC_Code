g++ main.cpp Employee.cpp -o employee_program
